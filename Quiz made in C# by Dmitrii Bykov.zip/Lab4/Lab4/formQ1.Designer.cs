﻿namespace Lab4
{
    partial class formQ1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblQ1 = new System.Windows.Forms.Label();
            this.btnSubmitQ1 = new System.Windows.Forms.Button();
            this.btnNextQ1 = new System.Windows.Forms.Button();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.rbtnA1 = new System.Windows.Forms.RadioButton();
            this.rbtnB1 = new System.Windows.Forms.RadioButton();
            this.rbtnC1 = new System.Windows.Forms.RadioButton();
            this.tmrQ1 = new System.Windows.Forms.Timer(this.components);
            this.lblTimeleft = new System.Windows.Forms.Label();
            this.lblSeconds = new System.Windows.Forms.Label();
            this.prgbarQ1 = new System.Windows.Forms.ProgressBar();
            this.lblPercent = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblQ1
            // 
            this.lblQ1.AutoSize = true;
            this.lblQ1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ1.Location = new System.Drawing.Point(42, 42);
            this.lblQ1.Name = "lblQ1";
            this.lblQ1.Size = new System.Drawing.Size(162, 32);
            this.lblQ1.TabIndex = 0;
            this.lblQ1.Text = "Question#1";
            // 
            // btnSubmitQ1
            // 
            this.btnSubmitQ1.Location = new System.Drawing.Point(117, 404);
            this.btnSubmitQ1.Name = "btnSubmitQ1";
            this.btnSubmitQ1.Size = new System.Drawing.Size(87, 30);
            this.btnSubmitQ1.TabIndex = 1;
            this.btnSubmitQ1.Text = "Submit";
            this.btnSubmitQ1.UseVisualStyleBackColor = true;
            this.btnSubmitQ1.Click += new System.EventHandler(this.btnSubmitQ1_Click);
            // 
            // btnNextQ1
            // 
            this.btnNextQ1.Location = new System.Drawing.Point(427, 404);
            this.btnNextQ1.Name = "btnNextQ1";
            this.btnNextQ1.Size = new System.Drawing.Size(84, 30);
            this.btnNextQ1.TabIndex = 2;
            this.btnNextQ1.Text = "Next";
            this.btnNextQ1.UseVisualStyleBackColor = true;
            this.btnNextQ1.Click += new System.EventHandler(this.btnNextQ1_Click);
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(35, 95);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(388, 25);
            this.lblQuestion.TabIndex = 3;
            this.lblQuestion.Text = "What type of programming language is C#?";
            // 
            // rbtnA1
            // 
            this.rbtnA1.AutoSize = true;
            this.rbtnA1.Location = new System.Drawing.Point(95, 166);
            this.rbtnA1.Name = "rbtnA1";
            this.rbtnA1.Size = new System.Drawing.Size(171, 24);
            this.rbtnA1.TabIndex = 4;
            this.rbtnA1.TabStop = true;
            this.rbtnA1.Text = "(A) Object-Oriented";
            this.rbtnA1.UseVisualStyleBackColor = true;
            // 
            // rbtnB1
            // 
            this.rbtnB1.AutoSize = true;
            this.rbtnB1.Location = new System.Drawing.Point(95, 230);
            this.rbtnB1.Name = "rbtnB1";
            this.rbtnB1.Size = new System.Drawing.Size(150, 24);
            this.rbtnB1.TabIndex = 5;
            this.rbtnB1.TabStop = true;
            this.rbtnB1.Text = "(B) Event-Driven";
            this.rbtnB1.UseVisualStyleBackColor = true;
            // 
            // rbtnC1
            // 
            this.rbtnC1.AutoSize = true;
            this.rbtnC1.Location = new System.Drawing.Point(95, 296);
            this.rbtnC1.Name = "rbtnC1";
            this.rbtnC1.Size = new System.Drawing.Size(127, 24);
            this.rbtnC1.TabIndex = 6;
            this.rbtnC1.TabStop = true;
            this.rbtnC1.Text = "(C) Assembly";
            this.rbtnC1.UseVisualStyleBackColor = true;
            // 
            // tmrQ1
            // 
            this.tmrQ1.Enabled = true;
            this.tmrQ1.Interval = 1000;
            this.tmrQ1.Tick += new System.EventHandler(this.tmrQ1_Tick);
            // 
            // lblTimeleft
            // 
            this.lblTimeleft.AutoSize = true;
            this.lblTimeleft.Location = new System.Drawing.Point(36, 351);
            this.lblTimeleft.Name = "lblTimeleft";
            this.lblTimeleft.Size = new System.Drawing.Size(91, 20);
            this.lblTimeleft.TabIndex = 7;
            this.lblTimeleft.Text = "Time left =>";
            // 
            // lblSeconds
            // 
            this.lblSeconds.AutoSize = true;
            this.lblSeconds.Location = new System.Drawing.Point(133, 351);
            this.lblSeconds.Name = "lblSeconds";
            this.lblSeconds.Size = new System.Drawing.Size(27, 20);
            this.lblSeconds.TabIndex = 8;
            this.lblSeconds.Text = "10";
            // 
            // prgbarQ1
            // 
            this.prgbarQ1.Location = new System.Drawing.Point(353, 336);
            this.prgbarQ1.Name = "prgbarQ1";
            this.prgbarQ1.Size = new System.Drawing.Size(158, 35);
            this.prgbarQ1.TabIndex = 9;
            // 
            // lblPercent
            // 
            this.lblPercent.AutoSize = true;
            this.lblPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPercent.Location = new System.Drawing.Point(394, 318);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(81, 15);
            this.lblPercent.TabIndex = 10;
            this.lblPercent.Text = "% Completed";
            // 
            // formQ1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(648, 444);
            this.Controls.Add(this.lblPercent);
            this.Controls.Add(this.prgbarQ1);
            this.Controls.Add(this.lblSeconds);
            this.Controls.Add(this.lblTimeleft);
            this.Controls.Add(this.rbtnC1);
            this.Controls.Add(this.rbtnB1);
            this.Controls.Add(this.rbtnA1);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.btnNextQ1);
            this.Controls.Add(this.btnSubmitQ1);
            this.Controls.Add(this.lblQ1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "formQ1";
            this.Text = "formQ1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQ1;
        private System.Windows.Forms.Button btnSubmitQ1;
        private System.Windows.Forms.Button btnNextQ1;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.RadioButton rbtnA1;
        private System.Windows.Forms.RadioButton rbtnB1;
        private System.Windows.Forms.RadioButton rbtnC1;
        private System.Windows.Forms.Timer tmrQ1;
        private System.Windows.Forms.Label lblTimeleft;
        private System.Windows.Forms.Label lblSeconds;
        private System.Windows.Forms.ProgressBar prgbarQ1;
        private System.Windows.Forms.Label lblPercent;
    }
}