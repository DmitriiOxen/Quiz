﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Lab4
{
    public partial class formEnd : Form
    {
        int[] correctAnswers = formQ5.getAnswers.answers;
        string[] quizAnswers = { "(B) Event-Driven", "(B) 4 bytes", "(A)True", "(C) int arr[ ][ ][ ]", "(B) catch(exceptionType excObj) { }" };
        string[] lblText = new string[5];
        int mark = 0;
        string markOut = "";
        StreamWriter fileOut = File.AppendText("quizEntries.txt");
        public formEnd()
        {
            InitializeComponent();
            int i = 0;
            for(i=0;i<5;i++)
            {
                if(correctAnswers[i] == 1)
                {
                    lblText[i] = "Correct";
                } else
                {
                    lblText[i] = "Wrong,\ncorrect answer: " + quizAnswers[i];
                }
                mark += correctAnswers[i];
            }
            lblAnsw1.Text = lblText[0];
            lblAnsw2.Text = lblText[1];
            lblAnsw3.Text = lblText[2];
            lblAnsw4.Text = lblText[3];
            lblAnsw5.Text = lblText[4];
            switch(mark)
            {
                case 5:
                    lblMark.Text = "Mark: A";
                    markOut = "Mark: A";
                    break;
                case 4:
                    lblMark.Text = "Mark: B";
                    markOut = "Mark: B";
                    break;
                case 3:
                    lblMark.Text = "Mark: C";
                    markOut = "Mark: C";
                    break;
                case 2:
                    lblMark.Text = "Mark: C--";
                    markOut = "Mark: C--";
                    break;
                case 1:
                    lblMark.Text = "Mark: D";
                    markOut = "Mark: D";
                    break;
                case 0:
                    lblMark.Text = "Mark: F";
                    markOut = "Mark: F";
                    break;
            }
            fileOut.WriteLine("Name: " + formID.getNames.name + ", ID: " + formID.getNames.id + ", " + markOut );
            fileOut.Close();
        }

        public static class getAnswers
        {
            public static int[] answers { get; set; }
            public static string[] quizAnsw { get; set; }
        }

        public static class getNames
        {
            public static string name { get; set; }
            public static string id { get; set; }
        }
    }
}
