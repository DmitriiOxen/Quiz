﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class formQ3 : Form
    {
        bool submitClick = false;
        int[] correctAnswers = formQ2.getAnswers.answers;
        int ticks = 10;
        string[] quizAnswers = formQ2.getAnswers.quizAnsw;
        public formQ3()
        {
            InitializeComponent();
            prgbarQ3.Maximum = 100;
            prgbarQ3.Step = 20;
            foreach (int i in correctAnswers)
            {
                if (i == 1)
                    prgbarQ3.PerformStep();
            }
        }

        public static class getAnswers
        {
            public static int[] answers { get; set; }
            public static string[] quizAnsw { get; set; }
        }

        private void btnSubmitQ3_Click(object sender, EventArgs e)
        {
            if (rbtnA3.Checked == true)
            {
                correctAnswers[2] = 1;
                prgbarQ3.PerformStep();
            }
            submitClick = true;
            btnSubmitQ3.Hide();
            getAnswers.answers = correctAnswers;
            quizAnswers[2] = rbtnA3.Text;
            getAnswers.quizAnsw = quizAnswers;
        }

        private void tmrQ2_Tick(object sender, EventArgs e)
        {
            if (ticks != 0)
            {
                ticks -= 1;
                lblSeconds.Text = ticks.ToString();
            }
            else
            {
                rbtnA3.Visible = false;
                rbtnB3.Visible = false;
                btnSubmitQ3.Visible = false;
                tmrQ3.Enabled = false;
            }
        }

        private void btnNextQ3_Click(object sender, EventArgs e)
        {
            if (submitClick == false)
            {
                correctAnswers[2] = 0;
                getAnswers.answers = correctAnswers;
                quizAnswers[2] = rbtnA3.Text;
                getAnswers.quizAnsw = quizAnswers;
            }
            this.Hide();
            formQ4 frmQ4 = new formQ4();
            frmQ4.ShowDialog();
            this.Close();
        }
    }
}
