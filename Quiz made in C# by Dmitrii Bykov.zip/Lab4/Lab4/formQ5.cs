﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class formQ5 : Form
    {
        bool submitClick = false;
        int[] correctAnswers = formQ4.getAnswers.answers;
        int ticks = 10;
        string[] quizAnswers = formQ4.getAnswers.quizAnsw;
        public formQ5()
        {
            InitializeComponent();
            prgbarQ5.Maximum = 100;
            prgbarQ5.Step = 20;
            foreach (int i in correctAnswers)
            {
                if (i == 1)
                    prgbarQ5.PerformStep();
            }
        }

        public static class getAnswers
        {
            public static int[] answers { get; set; }
            public static string[] quizAnsw { get; set; }
        }

        private void btnSubmitQ5_Click(object sender, EventArgs e)
        {
            if (rbtnB5.Checked == true)
            {
                correctAnswers[4] = 1;
                prgbarQ5.PerformStep();
            }
            submitClick = true;
            btnSubmitQ5.Hide();
            getAnswers.answers = correctAnswers;
            quizAnswers[4] = rbtnB5.Text;
            getAnswers.quizAnsw = quizAnswers;
        }

        private void tmrQ5_Tick(object sender, EventArgs e)
        {
            if (ticks != 0)
            {
                ticks -= 1;
                lblSeconds.Text = ticks.ToString();
            }
            else
            {
                rbtnA5.Visible = false;
                rbtnB5.Visible = false;
                rbtnC5.Visible = false;
                btnSubmitQ5.Visible = false;
                tmrQ5.Enabled = false;
            }
        }

        private void btnNextQ5_Click(object sender, EventArgs e)
        {
            if (submitClick == false)
            {
                correctAnswers[1] = 0;
                getAnswers.answers = correctAnswers;
                quizAnswers[1] = rbtnB5.Text;
                getAnswers.quizAnsw = quizAnswers;
            }
            this.Hide();
            formEnd frmEnd = new formEnd();
            frmEnd.ShowDialog();
            this.Close();
        }
    }
}
