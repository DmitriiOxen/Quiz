﻿namespace Lab4
{
    partial class formQ5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.lblQ5 = new System.Windows.Forms.Label();
            this.rbtnC5 = new System.Windows.Forms.RadioButton();
            this.rbtnB5 = new System.Windows.Forms.RadioButton();
            this.rbtnA5 = new System.Windows.Forms.RadioButton();
            this.btnNextQ5 = new System.Windows.Forms.Button();
            this.btnSubmitQ5 = new System.Windows.Forms.Button();
            this.lblPercent = new System.Windows.Forms.Label();
            this.prgbarQ5 = new System.Windows.Forms.ProgressBar();
            this.lblSeconds = new System.Windows.Forms.Label();
            this.lblTimeleft = new System.Windows.Forms.Label();
            this.tmrQ5 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(27, 85);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(597, 50);
            this.lblQuestion.TabIndex = 10;
            this.lblQuestion.Text = "C# exception handling mechanism uses a try block, catch block and\r\na finally bloc" +
    "k. In which of those 3 blocks an exception is handled?";
            this.lblQuestion.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblQ5
            // 
            this.lblQ5.AutoSize = true;
            this.lblQ5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ5.Location = new System.Drawing.Point(42, 42);
            this.lblQ5.Name = "lblQ5";
            this.lblQ5.Size = new System.Drawing.Size(162, 32);
            this.lblQ5.TabIndex = 9;
            this.lblQ5.Text = "Question#5";
            // 
            // rbtnC5
            // 
            this.rbtnC5.AutoSize = true;
            this.rbtnC5.Location = new System.Drawing.Point(56, 262);
            this.rbtnC5.Name = "rbtnC5";
            this.rbtnC5.Size = new System.Drawing.Size(116, 24);
            this.rbtnC5.TabIndex = 34;
            this.rbtnC5.TabStop = true;
            this.rbtnC5.Text = "(C) finally { }";
            this.rbtnC5.UseVisualStyleBackColor = true;
            // 
            // rbtnB5
            // 
            this.rbtnB5.AutoSize = true;
            this.rbtnB5.Location = new System.Drawing.Point(56, 210);
            this.rbtnB5.Name = "rbtnB5";
            this.rbtnB5.Size = new System.Drawing.Size(280, 24);
            this.rbtnB5.TabIndex = 33;
            this.rbtnB5.TabStop = true;
            this.rbtnB5.Text = "(B) catch(exceptionType excObj) { }";
            this.rbtnB5.UseVisualStyleBackColor = true;
            // 
            // rbtnA5
            // 
            this.rbtnA5.AutoSize = true;
            this.rbtnA5.Location = new System.Drawing.Point(56, 158);
            this.rbtnA5.Name = "rbtnA5";
            this.rbtnA5.Size = new System.Drawing.Size(94, 24);
            this.rbtnA5.TabIndex = 32;
            this.rbtnA5.TabStop = true;
            this.rbtnA5.Text = "(A) try { }";
            this.rbtnA5.UseVisualStyleBackColor = true;
            // 
            // btnNextQ5
            // 
            this.btnNextQ5.Location = new System.Drawing.Point(399, 381);
            this.btnNextQ5.Name = "btnNextQ5";
            this.btnNextQ5.Size = new System.Drawing.Size(84, 30);
            this.btnNextQ5.TabIndex = 40;
            this.btnNextQ5.Text = "Next";
            this.btnNextQ5.UseVisualStyleBackColor = true;
            this.btnNextQ5.Click += new System.EventHandler(this.btnNextQ5_Click);
            // 
            // btnSubmitQ5
            // 
            this.btnSubmitQ5.Location = new System.Drawing.Point(89, 381);
            this.btnSubmitQ5.Name = "btnSubmitQ5";
            this.btnSubmitQ5.Size = new System.Drawing.Size(87, 30);
            this.btnSubmitQ5.TabIndex = 39;
            this.btnSubmitQ5.Text = "Submit";
            this.btnSubmitQ5.UseVisualStyleBackColor = true;
            this.btnSubmitQ5.Click += new System.EventHandler(this.btnSubmitQ5_Click);
            // 
            // lblPercent
            // 
            this.lblPercent.AutoSize = true;
            this.lblPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPercent.Location = new System.Drawing.Point(420, 301);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(81, 15);
            this.lblPercent.TabIndex = 38;
            this.lblPercent.Text = "% Completed";
            // 
            // prgbarQ5
            // 
            this.prgbarQ5.Location = new System.Drawing.Point(382, 319);
            this.prgbarQ5.Name = "prgbarQ5";
            this.prgbarQ5.Size = new System.Drawing.Size(158, 35);
            this.prgbarQ5.TabIndex = 37;
            // 
            // lblSeconds
            // 
            this.lblSeconds.AutoSize = true;
            this.lblSeconds.Location = new System.Drawing.Point(149, 334);
            this.lblSeconds.Name = "lblSeconds";
            this.lblSeconds.Size = new System.Drawing.Size(27, 20);
            this.lblSeconds.TabIndex = 36;
            this.lblSeconds.Text = "10";
            // 
            // lblTimeleft
            // 
            this.lblTimeleft.AutoSize = true;
            this.lblTimeleft.Location = new System.Drawing.Point(52, 334);
            this.lblTimeleft.Name = "lblTimeleft";
            this.lblTimeleft.Size = new System.Drawing.Size(91, 20);
            this.lblTimeleft.TabIndex = 35;
            this.lblTimeleft.Text = "Time left =>";
            // 
            // tmrQ5
            // 
            this.tmrQ5.Enabled = true;
            this.tmrQ5.Interval = 1000;
            this.tmrQ5.Tick += new System.EventHandler(this.tmrQ5_Tick);
            // 
            // formQ5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(666, 444);
            this.Controls.Add(this.btnNextQ5);
            this.Controls.Add(this.btnSubmitQ5);
            this.Controls.Add(this.lblPercent);
            this.Controls.Add(this.prgbarQ5);
            this.Controls.Add(this.lblSeconds);
            this.Controls.Add(this.lblTimeleft);
            this.Controls.Add(this.rbtnC5);
            this.Controls.Add(this.rbtnB5);
            this.Controls.Add(this.rbtnA5);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.lblQ5);
            this.Name = "formQ5";
            this.Text = "formQ5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Label lblQ5;
        private System.Windows.Forms.RadioButton rbtnC5;
        private System.Windows.Forms.RadioButton rbtnB5;
        private System.Windows.Forms.RadioButton rbtnA5;
        private System.Windows.Forms.Button btnNextQ5;
        private System.Windows.Forms.Button btnSubmitQ5;
        private System.Windows.Forms.Label lblPercent;
        private System.Windows.Forms.ProgressBar prgbarQ5;
        private System.Windows.Forms.Label lblSeconds;
        private System.Windows.Forms.Label lblTimeleft;
        private System.Windows.Forms.Timer tmrQ5;
    }
}