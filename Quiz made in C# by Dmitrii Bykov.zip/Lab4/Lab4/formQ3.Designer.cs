﻿namespace Lab4
{
    partial class formQ3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.lblQ3 = new System.Windows.Forms.Label();
            this.lblPercent = new System.Windows.Forms.Label();
            this.prgbarQ3 = new System.Windows.Forms.ProgressBar();
            this.lblSeconds = new System.Windows.Forms.Label();
            this.lblTimeleft = new System.Windows.Forms.Label();
            this.rbtnB3 = new System.Windows.Forms.RadioButton();
            this.rbtnA3 = new System.Windows.Forms.RadioButton();
            this.btnNextQ3 = new System.Windows.Forms.Button();
            this.btnSubmitQ3 = new System.Windows.Forms.Button();
            this.tmrQ3 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(43, 112);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(537, 50);
            this.lblQuestion.TabIndex = 6;
            this.lblQuestion.Text = "Are const data members are automatically static and must be\r\ninitialized when dec" +
    "lared?\r\n";
            // 
            // lblQ3
            // 
            this.lblQ3.AutoSize = true;
            this.lblQ3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ3.Location = new System.Drawing.Point(42, 42);
            this.lblQ3.Name = "lblQ3";
            this.lblQ3.Size = new System.Drawing.Size(162, 32);
            this.lblQ3.TabIndex = 5;
            this.lblQ3.Text = "Question#3";
            // 
            // lblPercent
            // 
            this.lblPercent.AutoSize = true;
            this.lblPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPercent.Location = new System.Drawing.Point(412, 303);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(81, 15);
            this.lblPercent.TabIndex = 24;
            this.lblPercent.Text = "% Completed";
            // 
            // prgbarQ3
            // 
            this.prgbarQ3.Location = new System.Drawing.Point(374, 321);
            this.prgbarQ3.Name = "prgbarQ3";
            this.prgbarQ3.Size = new System.Drawing.Size(158, 35);
            this.prgbarQ3.TabIndex = 23;
            // 
            // lblSeconds
            // 
            this.lblSeconds.AutoSize = true;
            this.lblSeconds.Location = new System.Drawing.Point(141, 336);
            this.lblSeconds.Name = "lblSeconds";
            this.lblSeconds.Size = new System.Drawing.Size(27, 20);
            this.lblSeconds.TabIndex = 22;
            this.lblSeconds.Text = "10";
            // 
            // lblTimeleft
            // 
            this.lblTimeleft.AutoSize = true;
            this.lblTimeleft.Location = new System.Drawing.Point(44, 336);
            this.lblTimeleft.Name = "lblTimeleft";
            this.lblTimeleft.Size = new System.Drawing.Size(91, 20);
            this.lblTimeleft.TabIndex = 21;
            this.lblTimeleft.Text = "Time left =>";
            // 
            // rbtnB3
            // 
            this.rbtnB3.AutoSize = true;
            this.rbtnB3.Location = new System.Drawing.Point(48, 246);
            this.rbtnB3.Name = "rbtnB3";
            this.rbtnB3.Size = new System.Drawing.Size(98, 24);
            this.rbtnB3.TabIndex = 19;
            this.rbtnB3.TabStop = true;
            this.rbtnB3.Text = "(B) False";
            this.rbtnB3.UseVisualStyleBackColor = true;
            // 
            // rbtnA3
            // 
            this.rbtnA3.AutoSize = true;
            this.rbtnA3.Location = new System.Drawing.Point(48, 192);
            this.rbtnA3.Name = "rbtnA3";
            this.rbtnA3.Size = new System.Drawing.Size(91, 24);
            this.rbtnA3.TabIndex = 18;
            this.rbtnA3.TabStop = true;
            this.rbtnA3.Text = "(A) True";
            this.rbtnA3.UseVisualStyleBackColor = true;
            // 
            // btnNextQ3
            // 
            this.btnNextQ3.Location = new System.Drawing.Point(391, 402);
            this.btnNextQ3.Name = "btnNextQ3";
            this.btnNextQ3.Size = new System.Drawing.Size(84, 30);
            this.btnNextQ3.TabIndex = 26;
            this.btnNextQ3.Text = "Next";
            this.btnNextQ3.UseVisualStyleBackColor = true;
            this.btnNextQ3.Click += new System.EventHandler(this.btnNextQ3_Click);
            // 
            // btnSubmitQ3
            // 
            this.btnSubmitQ3.Location = new System.Drawing.Point(81, 402);
            this.btnSubmitQ3.Name = "btnSubmitQ3";
            this.btnSubmitQ3.Size = new System.Drawing.Size(87, 30);
            this.btnSubmitQ3.TabIndex = 25;
            this.btnSubmitQ3.Text = "Submit";
            this.btnSubmitQ3.UseVisualStyleBackColor = true;
            this.btnSubmitQ3.Click += new System.EventHandler(this.btnSubmitQ3_Click);
            // 
            // tmrQ3
            // 
            this.tmrQ3.Enabled = true;
            this.tmrQ3.Interval = 1000;
            this.tmrQ3.Tick += new System.EventHandler(this.tmrQ2_Tick);
            // 
            // formQ3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(648, 444);
            this.Controls.Add(this.btnNextQ3);
            this.Controls.Add(this.btnSubmitQ3);
            this.Controls.Add(this.lblPercent);
            this.Controls.Add(this.prgbarQ3);
            this.Controls.Add(this.lblSeconds);
            this.Controls.Add(this.lblTimeleft);
            this.Controls.Add(this.rbtnB3);
            this.Controls.Add(this.rbtnA3);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.lblQ3);
            this.Name = "formQ3";
            this.Text = "formQ3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Label lblQ3;
        private System.Windows.Forms.Label lblPercent;
        private System.Windows.Forms.ProgressBar prgbarQ3;
        private System.Windows.Forms.Label lblSeconds;
        private System.Windows.Forms.Label lblTimeleft;
        private System.Windows.Forms.RadioButton rbtnB3;
        private System.Windows.Forms.RadioButton rbtnA3;
        private System.Windows.Forms.Button btnNextQ3;
        private System.Windows.Forms.Button btnSubmitQ3;
        private System.Windows.Forms.Timer tmrQ3;
    }
}