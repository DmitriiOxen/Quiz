﻿namespace Lab4
{
    partial class formQ4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.lblQ4 = new System.Windows.Forms.Label();
            this.lblPercent = new System.Windows.Forms.Label();
            this.prgbarQ4 = new System.Windows.Forms.ProgressBar();
            this.lblSeconds = new System.Windows.Forms.Label();
            this.lblTimeleft = new System.Windows.Forms.Label();
            this.rbtnB4 = new System.Windows.Forms.RadioButton();
            this.rbtnA4 = new System.Windows.Forms.RadioButton();
            this.rbtnC4 = new System.Windows.Forms.RadioButton();
            this.btnNextQ4 = new System.Windows.Forms.Button();
            this.btnSubmitQ4 = new System.Windows.Forms.Button();
            this.tmrQ4 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(43, 96);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(462, 50);
            this.lblQuestion.TabIndex = 8;
            this.lblQuestion.Text = "Which of the choices below represents a declaration\r\nof a jagged array?\r\n";
            // 
            // lblQ4
            // 
            this.lblQ4.AutoSize = true;
            this.lblQ4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ4.Location = new System.Drawing.Point(42, 42);
            this.lblQ4.Name = "lblQ4";
            this.lblQ4.Size = new System.Drawing.Size(162, 32);
            this.lblQ4.TabIndex = 7;
            this.lblQ4.Text = "Question#4";
            // 
            // lblPercent
            // 
            this.lblPercent.AutoSize = true;
            this.lblPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPercent.Location = new System.Drawing.Point(412, 302);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(81, 15);
            this.lblPercent.TabIndex = 30;
            this.lblPercent.Text = "% Completed";
            // 
            // prgbarQ4
            // 
            this.prgbarQ4.Location = new System.Drawing.Point(374, 320);
            this.prgbarQ4.Name = "prgbarQ4";
            this.prgbarQ4.Size = new System.Drawing.Size(158, 35);
            this.prgbarQ4.TabIndex = 29;
            // 
            // lblSeconds
            // 
            this.lblSeconds.AutoSize = true;
            this.lblSeconds.Location = new System.Drawing.Point(141, 335);
            this.lblSeconds.Name = "lblSeconds";
            this.lblSeconds.Size = new System.Drawing.Size(27, 20);
            this.lblSeconds.TabIndex = 28;
            this.lblSeconds.Text = "10";
            // 
            // lblTimeleft
            // 
            this.lblTimeleft.AutoSize = true;
            this.lblTimeleft.Location = new System.Drawing.Point(44, 335);
            this.lblTimeleft.Name = "lblTimeleft";
            this.lblTimeleft.Size = new System.Drawing.Size(91, 20);
            this.lblTimeleft.TabIndex = 27;
            this.lblTimeleft.Text = "Time left =>";
            // 
            // rbtnB4
            // 
            this.rbtnB4.AutoSize = true;
            this.rbtnB4.Location = new System.Drawing.Point(48, 218);
            this.rbtnB4.Name = "rbtnB4";
            this.rbtnB4.Size = new System.Drawing.Size(174, 24);
            this.rbtnB4.TabIndex = 26;
            this.rbtnB4.TabStop = true;
            this.rbtnB4.Text = "(B) double array[ , , ]";
            this.rbtnB4.UseVisualStyleBackColor = true;
            // 
            // rbtnA4
            // 
            this.rbtnA4.AutoSize = true;
            this.rbtnA4.Location = new System.Drawing.Point(48, 166);
            this.rbtnA4.Name = "rbtnA4";
            this.rbtnA4.Size = new System.Drawing.Size(127, 24);
            this.rbtnA4.TabIndex = 25;
            this.rbtnA4.TabStop = true;
            this.rbtnA4.Text = "(A) int array[ ]";
            this.rbtnA4.UseVisualStyleBackColor = true;
            // 
            // rbtnC4
            // 
            this.rbtnC4.AutoSize = true;
            this.rbtnC4.Location = new System.Drawing.Point(48, 270);
            this.rbtnC4.Name = "rbtnC4";
            this.rbtnC4.Size = new System.Drawing.Size(135, 24);
            this.rbtnC4.TabIndex = 31;
            this.rbtnC4.TabStop = true;
            this.rbtnC4.Text = "(C) int arr[ ][ ][ ]";
            this.rbtnC4.UseVisualStyleBackColor = true;
            // 
            // btnNextQ4
            // 
            this.btnNextQ4.Location = new System.Drawing.Point(391, 382);
            this.btnNextQ4.Name = "btnNextQ4";
            this.btnNextQ4.Size = new System.Drawing.Size(84, 30);
            this.btnNextQ4.TabIndex = 33;
            this.btnNextQ4.Text = "Next";
            this.btnNextQ4.UseVisualStyleBackColor = true;
            this.btnNextQ4.Click += new System.EventHandler(this.btnNextQ4_Click);
            // 
            // btnSubmitQ4
            // 
            this.btnSubmitQ4.Location = new System.Drawing.Point(81, 382);
            this.btnSubmitQ4.Name = "btnSubmitQ4";
            this.btnSubmitQ4.Size = new System.Drawing.Size(87, 30);
            this.btnSubmitQ4.TabIndex = 32;
            this.btnSubmitQ4.Text = "Submit";
            this.btnSubmitQ4.UseVisualStyleBackColor = true;
            this.btnSubmitQ4.Click += new System.EventHandler(this.btnSubmitQ4_Click);
            // 
            // tmrQ4
            // 
            this.tmrQ4.Enabled = true;
            this.tmrQ4.Interval = 1000;
            this.tmrQ4.Tick += new System.EventHandler(this.tmrQ4_Tick);
            // 
            // formQ4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(648, 444);
            this.Controls.Add(this.btnNextQ4);
            this.Controls.Add(this.btnSubmitQ4);
            this.Controls.Add(this.rbtnC4);
            this.Controls.Add(this.lblPercent);
            this.Controls.Add(this.prgbarQ4);
            this.Controls.Add(this.lblSeconds);
            this.Controls.Add(this.lblTimeleft);
            this.Controls.Add(this.rbtnB4);
            this.Controls.Add(this.rbtnA4);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.lblQ4);
            this.Name = "formQ4";
            this.Text = "formQ4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Label lblQ4;
        private System.Windows.Forms.Label lblPercent;
        private System.Windows.Forms.ProgressBar prgbarQ4;
        private System.Windows.Forms.Label lblSeconds;
        private System.Windows.Forms.Label lblTimeleft;
        private System.Windows.Forms.RadioButton rbtnB4;
        private System.Windows.Forms.RadioButton rbtnA4;
        private System.Windows.Forms.RadioButton rbtnC4;
        private System.Windows.Forms.Button btnNextQ4;
        private System.Windows.Forms.Button btnSubmitQ4;
        private System.Windows.Forms.Timer tmrQ4;
    }
}