﻿namespace Lab4
{
    partial class formIntro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIDForm = new System.Windows.Forms.Button();
            this.tboxWelcome = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnIDForm
            // 
            this.btnIDForm.Location = new System.Drawing.Point(362, 297);
            this.btnIDForm.Name = "btnIDForm";
            this.btnIDForm.Size = new System.Drawing.Size(202, 31);
            this.btnIDForm.TabIndex = 0;
            this.btnIDForm.Text = "Press to Begin";
            this.btnIDForm.UseVisualStyleBackColor = true;
            this.btnIDForm.Click += new System.EventHandler(this.btnIDForm_Click);
            // 
            // tboxWelcome
            // 
            this.tboxWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxWelcome.Location = new System.Drawing.Point(212, 53);
            this.tboxWelcome.Multiline = true;
            this.tboxWelcome.Name = "tboxWelcome";
            this.tboxWelcome.ReadOnly = true;
            this.tboxWelcome.Size = new System.Drawing.Size(499, 196);
            this.tboxWelcome.TabIndex = 1;
            // 
            // formIntro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(973, 454);
            this.Controls.Add(this.tboxWelcome);
            this.Controls.Add(this.btnIDForm);
            this.Name = "formIntro";
            this.Text = "PRG Test";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIDForm;
        private System.Windows.Forms.TextBox tboxWelcome;
    }
}

