﻿namespace Lab4
{
    partial class formQ2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblQ2 = new System.Windows.Forms.Label();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.lblPercent = new System.Windows.Forms.Label();
            this.prgbarQ2 = new System.Windows.Forms.ProgressBar();
            this.lblSeconds = new System.Windows.Forms.Label();
            this.lblTimeleft = new System.Windows.Forms.Label();
            this.rbtnC2 = new System.Windows.Forms.RadioButton();
            this.rbtnB2 = new System.Windows.Forms.RadioButton();
            this.rbtnA2 = new System.Windows.Forms.RadioButton();
            this.btnNextQ2 = new System.Windows.Forms.Button();
            this.btnSubmitQ2 = new System.Windows.Forms.Button();
            this.tmrQ2 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // lblQ2
            // 
            this.lblQ2.AutoSize = true;
            this.lblQ2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2.Location = new System.Drawing.Point(42, 42);
            this.lblQ2.Name = "lblQ2";
            this.lblQ2.Size = new System.Drawing.Size(162, 32);
            this.lblQ2.TabIndex = 1;
            this.lblQ2.Text = "Question#2";
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(43, 89);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(482, 50);
            this.lblQuestion.TabIndex = 4;
            this.lblQuestion.Text = "What size in bytes does an integer variable(int) require\r\n in a system?";
            // 
            // lblPercent
            // 
            this.lblPercent.AutoSize = true;
            this.lblPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPercent.Location = new System.Drawing.Point(412, 303);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(81, 15);
            this.lblPercent.TabIndex = 17;
            this.lblPercent.Text = "% Completed";
            // 
            // prgbarQ2
            // 
            this.prgbarQ2.Location = new System.Drawing.Point(374, 321);
            this.prgbarQ2.Name = "prgbarQ2";
            this.prgbarQ2.Size = new System.Drawing.Size(158, 35);
            this.prgbarQ2.TabIndex = 16;
            // 
            // lblSeconds
            // 
            this.lblSeconds.AutoSize = true;
            this.lblSeconds.Location = new System.Drawing.Point(141, 336);
            this.lblSeconds.Name = "lblSeconds";
            this.lblSeconds.Size = new System.Drawing.Size(27, 20);
            this.lblSeconds.TabIndex = 15;
            this.lblSeconds.Text = "10";
            // 
            // lblTimeleft
            // 
            this.lblTimeleft.AutoSize = true;
            this.lblTimeleft.Location = new System.Drawing.Point(44, 336);
            this.lblTimeleft.Name = "lblTimeleft";
            this.lblTimeleft.Size = new System.Drawing.Size(91, 20);
            this.lblTimeleft.TabIndex = 14;
            this.lblTimeleft.Text = "Time left =>";
            // 
            // rbtnC2
            // 
            this.rbtnC2.AutoSize = true;
            this.rbtnC2.Location = new System.Drawing.Point(48, 281);
            this.rbtnC2.Name = "rbtnC2";
            this.rbtnC2.Size = new System.Drawing.Size(110, 24);
            this.rbtnC2.TabIndex = 13;
            this.rbtnC2.TabStop = true;
            this.rbtnC2.Text = "(C) 8 bytes";
            this.rbtnC2.UseVisualStyleBackColor = true;
            // 
            // rbtnB2
            // 
            this.rbtnB2.AutoSize = true;
            this.rbtnB2.Location = new System.Drawing.Point(48, 215);
            this.rbtnB2.Name = "rbtnB2";
            this.rbtnB2.Size = new System.Drawing.Size(110, 24);
            this.rbtnB2.TabIndex = 12;
            this.rbtnB2.TabStop = true;
            this.rbtnB2.Text = "(B) 4 bytes";
            this.rbtnB2.UseVisualStyleBackColor = true;
            // 
            // rbtnA2
            // 
            this.rbtnA2.AutoSize = true;
            this.rbtnA2.Location = new System.Drawing.Point(48, 151);
            this.rbtnA2.Name = "rbtnA2";
            this.rbtnA2.Size = new System.Drawing.Size(110, 24);
            this.rbtnA2.TabIndex = 11;
            this.rbtnA2.TabStop = true;
            this.rbtnA2.Text = "(A) 2 bytes";
            this.rbtnA2.UseVisualStyleBackColor = true;
            // 
            // btnNextQ2
            // 
            this.btnNextQ2.Location = new System.Drawing.Point(398, 402);
            this.btnNextQ2.Name = "btnNextQ2";
            this.btnNextQ2.Size = new System.Drawing.Size(84, 30);
            this.btnNextQ2.TabIndex = 19;
            this.btnNextQ2.Text = "Next";
            this.btnNextQ2.UseVisualStyleBackColor = true;
            this.btnNextQ2.Click += new System.EventHandler(this.btnNextQ2_Click);
            // 
            // btnSubmitQ2
            // 
            this.btnSubmitQ2.Location = new System.Drawing.Point(88, 402);
            this.btnSubmitQ2.Name = "btnSubmitQ2";
            this.btnSubmitQ2.Size = new System.Drawing.Size(87, 30);
            this.btnSubmitQ2.TabIndex = 18;
            this.btnSubmitQ2.Text = "Submit";
            this.btnSubmitQ2.UseVisualStyleBackColor = true;
            this.btnSubmitQ2.Click += new System.EventHandler(this.btnSubmitQ2_Click);
            // 
            // tmrQ2
            // 
            this.tmrQ2.Enabled = true;
            this.tmrQ2.Interval = 1000;
            this.tmrQ2.Tick += new System.EventHandler(this.tmrQ2_Tick);
            // 
            // formQ2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(648, 444);
            this.Controls.Add(this.btnNextQ2);
            this.Controls.Add(this.btnSubmitQ2);
            this.Controls.Add(this.lblPercent);
            this.Controls.Add(this.prgbarQ2);
            this.Controls.Add(this.lblSeconds);
            this.Controls.Add(this.lblTimeleft);
            this.Controls.Add(this.rbtnC2);
            this.Controls.Add(this.rbtnB2);
            this.Controls.Add(this.rbtnA2);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.lblQ2);
            this.Name = "formQ2";
            this.Text = "formQ2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQ2;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Label lblPercent;
        private System.Windows.Forms.ProgressBar prgbarQ2;
        private System.Windows.Forms.Label lblSeconds;
        private System.Windows.Forms.Label lblTimeleft;
        private System.Windows.Forms.RadioButton rbtnC2;
        private System.Windows.Forms.RadioButton rbtnB2;
        private System.Windows.Forms.RadioButton rbtnA2;
        private System.Windows.Forms.Button btnNextQ2;
        private System.Windows.Forms.Button btnSubmitQ2;
        private System.Windows.Forms.Timer tmrQ2;
    }
}