﻿namespace Lab4
{
    partial class formEnd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblResults = new System.Windows.Forms.Label();
            this.lblQ1 = new System.Windows.Forms.Label();
            this.lblQ2 = new System.Windows.Forms.Label();
            this.lblQ3 = new System.Windows.Forms.Label();
            this.lblQ4 = new System.Windows.Forms.Label();
            this.lblQ5 = new System.Windows.Forms.Label();
            this.lblAnsw1 = new System.Windows.Forms.Label();
            this.lblAnsw2 = new System.Windows.Forms.Label();
            this.lblAnsw3 = new System.Windows.Forms.Label();
            this.lblAnsw4 = new System.Windows.Forms.Label();
            this.lblAnsw5 = new System.Windows.Forms.Label();
            this.lblMark = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblResults
            // 
            this.lblResults.AutoSize = true;
            this.lblResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResults.Location = new System.Drawing.Point(42, 42);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(118, 32);
            this.lblResults.TabIndex = 10;
            this.lblResults.Text = "Results:";
            // 
            // lblQ1
            // 
            this.lblQ1.AutoSize = true;
            this.lblQ1.Location = new System.Drawing.Point(158, 93);
            this.lblQ1.Name = "lblQ1";
            this.lblQ1.Size = new System.Drawing.Size(86, 20);
            this.lblQ1.TabIndex = 11;
            this.lblQ1.Text = "Question1:";
            // 
            // lblQ2
            // 
            this.lblQ2.AutoSize = true;
            this.lblQ2.Location = new System.Drawing.Point(158, 141);
            this.lblQ2.Name = "lblQ2";
            this.lblQ2.Size = new System.Drawing.Size(86, 20);
            this.lblQ2.TabIndex = 12;
            this.lblQ2.Text = "Question2:";
            // 
            // lblQ3
            // 
            this.lblQ3.AutoSize = true;
            this.lblQ3.Location = new System.Drawing.Point(158, 189);
            this.lblQ3.Name = "lblQ3";
            this.lblQ3.Size = new System.Drawing.Size(86, 20);
            this.lblQ3.TabIndex = 13;
            this.lblQ3.Text = "Question3:";
            // 
            // lblQ4
            // 
            this.lblQ4.AutoSize = true;
            this.lblQ4.Location = new System.Drawing.Point(158, 238);
            this.lblQ4.Name = "lblQ4";
            this.lblQ4.Size = new System.Drawing.Size(86, 20);
            this.lblQ4.TabIndex = 14;
            this.lblQ4.Text = "Question4:";
            // 
            // lblQ5
            // 
            this.lblQ5.AutoSize = true;
            this.lblQ5.Location = new System.Drawing.Point(158, 283);
            this.lblQ5.Name = "lblQ5";
            this.lblQ5.Size = new System.Drawing.Size(86, 20);
            this.lblQ5.TabIndex = 15;
            this.lblQ5.Text = "Question5:";
            // 
            // lblAnsw1
            // 
            this.lblAnsw1.AutoSize = true;
            this.lblAnsw1.Location = new System.Drawing.Point(250, 93);
            this.lblAnsw1.Name = "lblAnsw1";
            this.lblAnsw1.Size = new System.Drawing.Size(61, 20);
            this.lblAnsw1.TabIndex = 16;
            this.lblAnsw1.Text = "Correct";
            // 
            // lblAnsw2
            // 
            this.lblAnsw2.AutoSize = true;
            this.lblAnsw2.Location = new System.Drawing.Point(250, 141);
            this.lblAnsw2.Name = "lblAnsw2";
            this.lblAnsw2.Size = new System.Drawing.Size(61, 20);
            this.lblAnsw2.TabIndex = 17;
            this.lblAnsw2.Text = "Correct";
            // 
            // lblAnsw3
            // 
            this.lblAnsw3.AutoSize = true;
            this.lblAnsw3.Location = new System.Drawing.Point(250, 189);
            this.lblAnsw3.Name = "lblAnsw3";
            this.lblAnsw3.Size = new System.Drawing.Size(61, 20);
            this.lblAnsw3.TabIndex = 18;
            this.lblAnsw3.Text = "Correct";
            // 
            // lblAnsw4
            // 
            this.lblAnsw4.AutoSize = true;
            this.lblAnsw4.Location = new System.Drawing.Point(250, 238);
            this.lblAnsw4.Name = "lblAnsw4";
            this.lblAnsw4.Size = new System.Drawing.Size(61, 20);
            this.lblAnsw4.TabIndex = 19;
            this.lblAnsw4.Text = "Correct";
            // 
            // lblAnsw5
            // 
            this.lblAnsw5.AutoSize = true;
            this.lblAnsw5.Location = new System.Drawing.Point(250, 283);
            this.lblAnsw5.Name = "lblAnsw5";
            this.lblAnsw5.Size = new System.Drawing.Size(61, 20);
            this.lblAnsw5.TabIndex = 20;
            this.lblAnsw5.Text = "Correct";
            // 
            // lblMark
            // 
            this.lblMark.AutoSize = true;
            this.lblMark.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMark.Location = new System.Drawing.Point(249, 350);
            this.lblMark.Name = "lblMark";
            this.lblMark.Size = new System.Drawing.Size(81, 25);
            this.lblMark.TabIndex = 21;
            this.lblMark.Text = "Mark: A";
            // 
            // formEnd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(648, 444);
            this.Controls.Add(this.lblMark);
            this.Controls.Add(this.lblAnsw5);
            this.Controls.Add(this.lblAnsw4);
            this.Controls.Add(this.lblAnsw3);
            this.Controls.Add(this.lblAnsw2);
            this.Controls.Add(this.lblAnsw1);
            this.Controls.Add(this.lblQ5);
            this.Controls.Add(this.lblQ4);
            this.Controls.Add(this.lblQ3);
            this.Controls.Add(this.lblQ2);
            this.Controls.Add(this.lblQ1);
            this.Controls.Add(this.lblResults);
            this.Name = "formEnd";
            this.Text = "formEnd";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.Label lblQ1;
        private System.Windows.Forms.Label lblQ2;
        private System.Windows.Forms.Label lblQ3;
        private System.Windows.Forms.Label lblQ4;
        private System.Windows.Forms.Label lblQ5;
        private System.Windows.Forms.Label lblAnsw1;
        private System.Windows.Forms.Label lblAnsw2;
        private System.Windows.Forms.Label lblAnsw3;
        private System.Windows.Forms.Label lblAnsw4;
        private System.Windows.Forms.Label lblAnsw5;
        private System.Windows.Forms.Label lblMark;
    }
}