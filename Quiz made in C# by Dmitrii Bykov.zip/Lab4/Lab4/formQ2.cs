﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class formQ2 : Form
    {
        bool submitClick = false;
        int[] correctAnswers = formQ1.getAnswers.answers;
        int ticks = 10;
        string[] quizAnswers = formQ1.getAnswers.quizAnsw;

        public formQ2()
        {
            InitializeComponent();
            prgbarQ2.Maximum = 100;
            prgbarQ2.Step = 20;
            foreach(int i in correctAnswers)
            {
                if(i == 1)
                    prgbarQ2.PerformStep();
            }
        }

        public static class getAnswers
        {
            public static int[] answers { get; set; }
            public static string[] quizAnsw { get; set; }
        }

        private void btnSubmitQ2_Click(object sender, EventArgs e)
        {
            if (rbtnB2.Checked == true)
            {
                correctAnswers[1] = 1;
                prgbarQ2.PerformStep();
            }
            submitClick = true;
            btnSubmitQ2.Hide();
            getAnswers.answers = correctAnswers;
            quizAnswers[1] = rbtnB2.Text;
            getAnswers.quizAnsw = quizAnswers;
        }

        private void tmrQ2_Tick(object sender, EventArgs e)
        {
            if (ticks != 0)
            {
                ticks -= 1;
                lblSeconds.Text = ticks.ToString();
            }
            else
            {
                rbtnA2.Visible = false;
                rbtnB2.Visible = false;
                rbtnC2.Visible = false;
                btnSubmitQ2.Visible = false;
                tmrQ2.Enabled = false;
            }
        }

        private void btnNextQ2_Click(object sender, EventArgs e)
        {
            if (submitClick == false)
            {
                correctAnswers[1] = 0;
                getAnswers.answers = correctAnswers;
                quizAnswers[1] = rbtnB2.Text;
                getAnswers.quizAnsw = quizAnswers;
            }
            this.Hide();
            formQ3 frmQ3 = new formQ3();
            frmQ3.ShowDialog();
            this.Close();
        }
    }
}
