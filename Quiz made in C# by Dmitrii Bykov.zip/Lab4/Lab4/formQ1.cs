﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class formQ1 : Form
    {
        bool submitClick = false;
        public int[] correctAnswers = {0, 0, 0, 0, 0};
        public int ticks = 10;
        string[] quizAnswers = new string[5];

        public formQ1()
        {
            InitializeComponent();
            prgbarQ1.Maximum = 100;
            prgbarQ1.Step = 20;
        }

        public static class getAnswers
        {
            public static int[] answers { get; set; }
            public static string[] quizAnsw { get; set; }

        }

        private void btnSubmitQ1_Click(object sender, EventArgs e)
        {
            if(rbtnB1.Checked == true)
            {
                correctAnswers[0] = 1;
                prgbarQ1.PerformStep();
            }
            submitClick = true;
            btnSubmitQ1.Hide();
            getAnswers.answers = correctAnswers;
            quizAnswers[0] = rbtnB1.Text;
            getAnswers.quizAnsw = quizAnswers;
        }
        
        private void tmrQ1_Tick(object sender, EventArgs e)
        {
            if(ticks != 0)
            {
                ticks -= 1;
                lblSeconds.Text = ticks.ToString();
            } else
            {
                rbtnA1.Visible = false;
                rbtnB1.Visible = false;
                rbtnC1.Visible = false;
                btnSubmitQ1.Visible = false;
                tmrQ1.Enabled = false;
            }
        }

        private void btnNextQ1_Click(object sender, EventArgs e)
        {
            if (submitClick == false)
            {
                correctAnswers[0] = 0;
                getAnswers.answers = correctAnswers;
                quizAnswers[0] = rbtnB1.Text;
                getAnswers.quizAnsw = quizAnswers;
            }
            this.Hide();
            formQ2 frmQ2 = new formQ2();
            frmQ2.ShowDialog();
            this.Close();
        }
    }
}