﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class formQ4 : Form
    {
        bool submitClick = false;
        int[] correctAnswers = formQ3.getAnswers.answers;
        int ticks = 10;
        string[] quizAnswers = formQ3.getAnswers.quizAnsw;
        public formQ4()
        {
            InitializeComponent();
            prgbarQ4.Maximum = 100;
            prgbarQ4.Step = 20;
            foreach (int i in correctAnswers)
            {
                if (i == 1)
                    prgbarQ4.PerformStep();
            }
        }

        public static class getAnswers
        {
            public static int[] answers { get; set; }
            public static string[] quizAnsw { get; set; }
        }

        private void btnSubmitQ4_Click(object sender, EventArgs e)
        {
            if (rbtnC4.Checked == true)
            {
                correctAnswers[3] = 1;
                prgbarQ4.PerformStep();
            }
            submitClick = true;
            btnSubmitQ4.Hide();
            getAnswers.answers = correctAnswers;
            quizAnswers[3] = rbtnC4.Text;
            getAnswers.quizAnsw = quizAnswers;
        }

        private void tmrQ4_Tick(object sender, EventArgs e)
        {
            if (ticks != 0)
            {
                ticks -= 1;
                lblSeconds.Text = ticks.ToString();
            }
            else
            {
                rbtnA4.Visible = false;
                rbtnB4.Visible = false;
                rbtnC4.Visible = false;
                btnSubmitQ4.Visible = false;
                tmrQ4.Enabled = false;
            }
        }

        private void btnNextQ4_Click(object sender, EventArgs e)
        {
            if (submitClick == false)
            {
                correctAnswers[1] = 0;
                getAnswers.answers = correctAnswers;
                quizAnswers[1] = rbtnC4.Text;
                getAnswers.quizAnsw = quizAnswers;
            }
            this.Hide();
            formQ5 frmQ5 = new formQ5();
            frmQ5.ShowDialog();
            this.Close();
        }
    }
}
