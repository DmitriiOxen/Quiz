﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class formIntro : Form
    {
        public formIntro()
        {
            InitializeComponent();
            tboxWelcome.Text = "Welcome to the PRG Test!\n The test has 5 multiple choise qusetions. Every question has a time limit of 10 seconds, after reaching a time limit, test continues onto the next question and a previous question is considered wrong. Click the button below to start the test.";
        }

        private void btnIDForm_Click(object sender, EventArgs e)
        {
            this.Hide();
            formID frmID = new formID();
            frmID.ShowDialog();
            this.Close();
        }
    }
}