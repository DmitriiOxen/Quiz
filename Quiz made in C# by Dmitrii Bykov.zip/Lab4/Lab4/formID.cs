﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class formID : Form
    {
        public formID()
        {
            InitializeComponent();
        }

        int mistakes = 0;

        private void btnEnter_Click(object sender, EventArgs e)
        {
            if(mistakes != 3)
            {
                if (tboxName.Text != "" && tboxID.Text != "" && tboxPassword.Text == "prg455")
                {
                    getNames.name = tboxName.Text;
                    getNames.id = tboxID.Text;
                    this.Hide();
                    formQ1 frmQ1 = new formQ1();
                    frmQ1.ShowDialog();
                    this.Close();
                } else
                {
                    mistakes++;
                    MessageBox.Show("Wrong password or initials, check your input.");
                }
            } else
            {
                MessageBox.Show("Too many tries, access denied." + mistakes);
                Environment.Exit(1);
            }
        }

        public static class getNames
        {
            public static string name { get; set; }
            public static string id { get; set; }
        }
    }
}
